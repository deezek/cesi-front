export default {
  apiUrl: 'https://0337089f-abd4-479c-ba9a-c7d82b1c188f.mock.pstmn.io'
}