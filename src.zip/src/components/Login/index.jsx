import React from 'react';
import Axios from 'axios';
import config from '../config/index';
import { Link } from 'react-router-dom';

class Login extends React.Component{
  constructor() {
    super();
    this.state = {
      username: '',
      password: '',
    };
  }
  handleInputChange1 = (event) => {
    this.setState({
      username: event.target.value
    })
  }
  handleInputChange2 = (event) => {
    this.setState({
      password: event.target.value
    })
  }
  handleSubmit = (event) =>{
    event.preventDefault()
    console.log(this.state)

    var raw = JSON.stringify({
      "identifier": this.state.username,
      "password": this.state.password
    });
    
    var config = {
      method: 'post',
      url: 'http://localhost:1337/auth/local/',
      headers: { 
        'Content-Type': 'application/json'
      },
      data : raw
    };
    
    Axios(config)
    .then(function (response) {
      console.log(JSON.stringify(response.data));
    })
    .catch(function (error) {
      console.log(error);
    });
  }

  render(){
    return (
      <div className="mh-fullscreen bg-img center-vh p-20" style={{backgroundImage: `url(${process.env.PUBLIC_URL}/assets/img/bg-girl.jpg)`}}> 
    <div className="card card-shadowed p-50 w-400 mb-0" style={{maxWidth: '100%'}}>
      <h5 className="text-uppercase text-center">Login</h5>
      <br /><br /> 
      <form onSubmit={this.handleSubmit}>
        <div className="form-group">
          <input type="text" className="form-control" placeholder="Username" onChange={this.handleInputChange1} />
        </div>
        <div className="form-group">
          <input type="password" className="form-control" placeholder="Password" onChange={this.handleInputChange2} />
        </div>
        <div className="form-group flexbox py-10">
          <label className="custom-control custom-checkbox">
            <input type="checkbox" className="custom-control-input" defaultChecked />
            <span className="custom-control-indicator" />
            <span className="custom-control-description">Se souvenir de moi</span>
          </label>
          <a className="text-muted hover-primary fs-13" href="#">Mot de passe oublié ?</a>
        </div>
        <div className="form-group">
          <button className="btn btn-bold btn-block btn-primary" type="submit">Connexion</button>
        </div>
      </form>
      <hr className="w-30" />
      <p className="text-center text-muted fs-13 mt-20">Pas encore de compte ?<Link to="/signup">S'inscrire</Link></p>
    </div>
  </div>

    )
  }
}

export default Login;